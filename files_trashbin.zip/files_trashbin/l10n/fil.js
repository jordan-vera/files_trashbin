OC.L10N.register(
    "files_trashbin",
    {
    "Error" : "Error"
},
"nplurals=2; plural=(n > 1);");
