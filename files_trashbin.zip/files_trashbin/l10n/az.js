OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Silinmiş fayllar",
    "restored" : "geriqaytarılıb",
    "Restore" : "Geri qaytar",
    "Delete permanently" : "Həmişəlik sil",
    "This operation is forbidden" : "Bu əməliyyat qadağandır",
    "This directory is unavailable, please check the logs or contact the administrator" : "Bu qovluq tapılmir. Xahiş olunur jurnalları yoxlayın ya da inzibatçı ilə əlaqə saxlayın",
    "No deleted files" : "Silinmiş fayllar mövcud deyil",
    "You will be able to recover deleted files from here" : "Siz silinmiş faylları burdan bərpa edə bilərsiniz",
    "No entries found in this folder" : "Bu qovluqda heç bir verilən tapılmadı",
    "Select all" : "Hamısıı seç",
    "Name" : "Ad",
    "Actions" : "İşlər",
    "Deleted" : "Silinib",
    "Delete" : "Sil"
},
"nplurals=2; plural=(n != 1);");
