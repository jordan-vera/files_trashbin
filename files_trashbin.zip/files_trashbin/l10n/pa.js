OC.L10N.register(
    "files_trashbin",
    {
    "Delete" : "ਹਟਾਓ",
    "Error" : "ਗਲਤੀ"
},
"nplurals=2; plural=(n != 1);");
