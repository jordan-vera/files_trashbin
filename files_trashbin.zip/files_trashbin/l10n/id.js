OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Berkas yang dihapus",
    "restored" : "dipulihkan",
    "Restore" : "Pulihkan",
    "Delete permanently" : "Hapus secara permanen",
    "This operation is forbidden" : "Operasi ini dilarang",
    "This directory is unavailable, please check the logs or contact the administrator" : "Direktori ini tidak tersedia, silakan periksa log atau hubungi kontak",
    "No deleted files" : "Tidak ada berkas yang dihapus",
    "You will be able to recover deleted files from here" : "Anda dapat memulihkan berkas yang dihapus dari sini",
    "No entries found in this folder" : "Tidak ada entri yang ditemukan dalam folder ini",
    "Select all" : "Pilih Semua",
    "Name" : "Nama",
    "Actions" : "Tindakan",
    "Deleted" : "Dihapus",
    "Delete" : "Hapus"
},
"nplurals=1; plural=0;");
