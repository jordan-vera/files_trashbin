OC.L10N.register(
    "files_trashbin",
    {
    "Delete" : "刪除",
    "Error" : "錯誤",
    "Name" : "名稱"
},
"nplurals=1; plural=0;");
