OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Изтрити файлове",
    "restored" : "възстановено",
    "Restore" : "Възстановяне",
    "Delete permanently" : "Изтрий завинаги",
    "This operation is forbidden" : "Операцията е забранена",
    "This directory is unavailable, please check the logs or contact the administrator" : "Директорията не е налична. Моля проверете журнала или се свържете с администратор",
    "No deleted files" : "Няма изтрити файлове",
    "You will be able to recover deleted files from here" : "От тук можете да възстановите изтрити файлове",
    "No entries found in this folder" : "Няма намерени записи в тази папка",
    "Select all" : "Избери всички",
    "Name" : "Име",
    "Actions" : "Действия",
    "Deleted" : "Изтрито",
    "Delete" : "Изтрий"
},
"nplurals=2; plural=(n != 1);");
