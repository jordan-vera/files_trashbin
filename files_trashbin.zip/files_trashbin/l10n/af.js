OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Geskrapte lêers",
    "restored" : "herstel",
    "Restore" : "Herstel",
    "Delete permanently" : "Skrap permanent",
    "This operation is forbidden" : "Hierdie operasie is verbode",
    "This directory is unavailable, please check the logs or contact the administrator" : "Hierdie gids is onbeskikbaar, gaan die logs na of kontak die administrateur",
    "No deleted files" : "Geen geskrapte lêers",
    "You will be able to recover deleted files from here" : "U sal geskrapte lêers van hier kan herstel",
    "No entries found in this folder" : "Geen inskrwyings in hierdie vouer gevind",
    "Select all" : "Kies alle",
    "Name" : "Naam",
    "Actions" : "Aksies",
    "Deleted" : "Geskrap",
    "Delete" : "Skrap"
},
"nplurals=2; plural=(n != 1);");
