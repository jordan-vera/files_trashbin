OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Archivos borrados",
    "restored" : "restaurado",
    "Restore" : "Restaurar",
    "Delete permanently" : "Borrar permanentemente",
    "This operation is forbidden" : "Esta opración está prohibida",
    "This directory is unavailable, please check the logs or contact the administrator" : "Este directorio no está disponible, por favor verifica las bitácoras o contacta al administrador",
    "No deleted files" : "No hay archivos borrados",
    "You will be able to recover deleted files from here" : "Podrás recuperar archivos borrados desde aquí",
    "No entries found in this folder" : "No se encontraron elementos en esta carpeta",
    "Select all" : "Seleccionar todo",
    "Name" : "Nombre",
    "Actions" : "Acciones",
    "Deleted" : "Borrado",
    "Delete" : "Borrar"
},
"nplurals=2; plural=(n != 1);");
