OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "Methwyd dileu %s yn barhaol",
    "Couldn't restore %s" : "Methwyd adfer %s",
    "Deleted files" : "Ffeiliau ddilewyd",
    "Restore" : "Adfer",
    "Delete" : "Dileu",
    "Delete permanently" : "Dileu'n barhaol",
    "Error" : "Gwall",
    "Name" : "Enw",
    "Deleted" : "Wedi dileu"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
