OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Kartela të fshira",
    "restored" : "u rikthye",
    "Restore" : "Riktheje",
    "Delete permanently" : "Fshije përgjithmonë",
    "This operation is forbidden" : "Ky veprim është i ndaluar",
    "This directory is unavailable, please check the logs or contact the administrator" : "Kjo drejtori nuk kapet, ju lutemi, kontrolloni regjistrat ose lidhuni me përgjegjësin",
    "No deleted files" : "Pa kartela të fshira",
    "You will be able to recover deleted files from here" : "Që këtu do të jeni në gjendje të rimerrni kartela të fshira",
    "No entries found in this folder" : "Në këtë dosje s’u gjetën zëra",
    "Select all" : "Përzgjidhi krejt",
    "Name" : "Emër",
    "Actions" : "Veprimet",
    "Deleted" : "U fshi",
    "Delete" : "Fshije"
},
"nplurals=2; plural=(n != 1);");
