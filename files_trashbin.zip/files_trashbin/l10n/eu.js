OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Ezabatutako fitxategiak",
    "restored" : "Berrezarrita",
    "Restore" : "Berrezarri",
    "Delete permanently" : "Ezabatu betirako",
    "This operation is forbidden" : "Eragiketa hau debekatuta dago",
    "This directory is unavailable, please check the logs or contact the administrator" : "Direktorio hau ez dago erabilgarri, administratzailearekin harremanetan jarri",
    "No deleted files" : "Ez dago ezabatutako fitxategirik",
    "You will be able to recover deleted files from here" : "Hemendik ezabatutako fitxategiak berreskuratu ahal izango duzu",
    "No entries found in this folder" : "Ez da sarrerarik aurkitu karpeta honetan",
    "Select all" : "Hautatu dena",
    "Name" : "Izena",
    "Actions" : "Ekintzak",
    "Deleted" : "Ezabatuta",
    "Delete" : "Ezabatu"
},
"nplurals=2; plural=(n != 1);");
