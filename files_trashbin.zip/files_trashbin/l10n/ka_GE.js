OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "წაშლილი ფაილები",
    "restored" : "აღდგენილია",
    "Restore" : "აღდგენა",
    "Delete permanently" : "სამუდამოდ წაშლა",
    "This operation is forbidden" : "ოპერაცია აკრძალულია",
    "This directory is unavailable, please check the logs or contact the administrator" : "დირექტორია ხელმიუწვდომელია, გთხოვთ დაათვალიეროთ მოქმედებათა ისტორია ან დაუკავშირდეთ ადმინისტრატორს",
    "No deleted files" : "წაშლილი ფაილები ვერ მოიძებნა",
    "You will be able to recover deleted files from here" : "წაშლილი ფაილების აღდგენა შესაძლებელია აქ",
    "No entries found in this folder" : "დირექტორიაში ჩანაწერები ვერ მოიძებნა",
    "Select all" : "ყველას მონიშვნა",
    "Name" : "სახელი",
    "Actions" : "მოქმედებები",
    "Deleted" : "წაშლილი",
    "Delete" : "წაშლა"
},
"nplurals=2; plural=(n!=1);");
