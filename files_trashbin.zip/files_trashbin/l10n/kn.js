OC.L10N.register(
    "files_trashbin",
    {
    "Restore" : "ಮರುಸ್ಥಾಪಿಸು",
    "Delete" : "﻿ಅಳಿಸಿ",
    "Error" : "﻿ತಪ್ಪಾಗಿದೆ",
    "Select all" : "﻿ಎಲ್ಲಾ ಆಯ್ಕೆ ಮಾಡಿ",
    "Name" : "﻿ಹೆಸರು"
},
"nplurals=1; plural=0;");
