OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "Tidak dapat menghapuskan %s secara kekal",
    "Couldn't restore %s" : "Tidak dapat memulihkan %s",
    "Deleted files" : "Fail dipadam",
    "Restore" : "Pulihkan",
    "Delete" : "Padam",
    "Error" : "Ralat",
    "restored" : "dipulihkan",
    "Name" : "Nama",
    "Deleted" : "Dipadam"
},
"nplurals=1; plural=0;");
