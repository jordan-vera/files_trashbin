OC.L10N.register(
    "files_trashbin",
    {
    "Error" : "Fout"
},
"nplurals=2; plural=(n != 1);");
