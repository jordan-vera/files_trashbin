OC.L10N.register(
    "files_trashbin",
    {
    "Delete" : "Löschen",
    "Error" : "Fehler",
    "Name" : "Name"
},
"nplurals=2; plural=(n != 1);");
