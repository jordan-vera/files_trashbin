OC.L10N.register(
    "files_trashbin",
    {
    "Delete" : "తొలగించు",
    "Delete permanently" : "శాశ్వతంగా తొలగించు",
    "Error" : "పొరపాటు",
    "Name" : "పేరు"
},
"nplurals=2; plural=(n != 1);");
