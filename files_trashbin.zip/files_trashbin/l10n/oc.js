OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "Impossible de suprimir %s definitivament",
    "Couldn't restore %s" : "Impossible de restablir %s",
    "Deleted files" : "Fichièrs suprimits",
    "Restore" : "Restablir",
    "Delete" : "Suprimir",
    "Delete permanently" : "Suprimir de faiçon definitiva",
    "Error" : "Error",
    "This operation is forbidden" : "L'operacion es interdicha",
    "This directory is unavailable, please check the logs or contact the administrator" : "Aqueste repertòri es pas disponible. Consultatz los logs o contactatz vòstre administrator",
    "restored" : "restablit",
    "No deleted files" : "Cap de fichièr pas suprimit",
    "You will be able to recover deleted files from here" : "Poiretz restablir vòstres fichièrs suprimits aicí",
    "No entries found in this folder" : "Cap d'entrada pas trobada dins aqueste dorsièr",
    "Select all" : "Seleccionar tot",
    "Name" : "Nom",
    "Deleted" : "Escafat"
},
"nplurals=2; plural=(n > 1);");
