OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "স্থায়ীভাবে %s গুলি মুছে ফেলা যায়নি",
    "Couldn't restore %s" : "%s পুনরুদ্ধার করা যায়নি",
    "Deleted files" : "ফাইলস মুছে ফেলা হয়েছে",
    "Restore" : "পুনরুদ্ধার",
    "Delete" : "মুছে ফেলা",
    "Delete permanently" : "স্থায়ীভাবে মুছে দিন",
    "Error" : "ভুল",
    "restored" : "পুনরুদ্ধার করা হয়েছে",
    "Name" : "নাম",
    "Deleted" : "মুছে ফেলা হয়েছে"
},
"nplurals=2; plural=(n != 1);");
