OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Ficheros desaniciaos",
    "restored" : "restauróse",
    "Restore" : "Restaurar",
    "Delete permanently" : "Desaniciar dafechu",
    "This operation is forbidden" : "Esta operación ta prohibida",
    "This directory is unavailable, please check the logs or contact the administrator" : "Esti direutoriu nun ta disponible, por favor comprueba'l rexistru o contauta col alministrador",
    "No deleted files" : "Nun hai ficheros desaniciaos",
    "You will be able to recover deleted files from here" : "Dende equí sedrás a recureperar los ficheros desaniciaos",
    "No entries found in this folder" : "Nun s'alcontraron entraes nesti carpeta",
    "Select all" : "Esbillar too",
    "Name" : "Nome",
    "Actions" : "Aiciones",
    "Deleted" : "Desanicióse",
    "Delete" : "Desaniciar"
},
"nplurals=2; plural=(n != 1);");
