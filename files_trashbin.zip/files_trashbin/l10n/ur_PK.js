OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "حذف نہیں ہو سکتا %s مستقل طور پر",
    "Couldn't restore %s" : "بحال نہيں کيا جا سکتا %s",
    "Deleted files" : "حذف شدہ فائليں",
    "Restore" : "بحال",
    "Delete" : "حذف کریں",
    "Error" : "ایرر",
    "restored" : "بحال شدہ",
    "Name" : "اسم",
    "Deleted" : "حذف شدہ "
},
"nplurals=2; plural=(n != 1);");
