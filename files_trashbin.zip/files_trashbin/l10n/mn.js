OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Устгасан файлууд",
    "Restore" : "Сэргээх",
    "Delete permanently" : "Үүрд устгах",
    "This operation is forbidden" : "Энэ үйлдэл хориотой",
    "This directory is unavailable, please check the logs or contact the administrator" : "Энэ хавтас байхгүй байна, үйлдлийн лог шалгах эсвэл админ хэрэглэгчтэй холбогдоно уу.",
    "No entries found in this folder" : "Энэ хавтаст юм олдсонгүй",
    "Select all" : "Бүгдийг сонгох",
    "Name" : "Нэр",
    "Actions" : "Үйл ажиллагаа",
    "Deleted" : "Устгагдсан",
    "Delete" : "Устгах"
},
"nplurals=2; plural=(n != 1);");
