OC.L10N.register(
    "files_trashbin",
    {
    "Error" : "त्रुटि"
},
"nplurals=2; plural=(n != 1);");
