OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "ئۆچۈرۈلگەن ھۆججەتلەر",
    "Delete" : "ئۆچۈر",
    "Delete permanently" : "مەڭگۈلۈك ئۆچۈر",
    "Error" : "خاتالىق",
    "Name" : "ئاتى",
    "Deleted" : "ئۆچۈرۈلدى"
},
"nplurals=1; plural=0;");
