OC.L10N.register(
    "files_trashbin",
    {
    "Delete" : "நீக்குக",
    "Error" : "வழு",
    "Name" : "பெயர்"
},
"nplurals=2; plural=(n != 1);");
