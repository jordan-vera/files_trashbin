OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "File đã bị xóa",
    "restored" : "khôi phục",
    "Restore" : "Khôi phục",
    "Delete permanently" : "Xóa vĩnh vễn",
    "This operation is forbidden" : "Thao tác bị cấm",
    "This directory is unavailable, please check the logs or contact the administrator" : "Thư mục này không sẵn có, hãy kiểm tra log hoặc liên hệ người quản lý",
    "No deleted files" : "Không có tập tin bị xóa",
    "You will be able to recover deleted files from here" : "Bạn có thể phục hồi các file đã bị xóa từ đây",
    "No entries found in this folder" : "Chưa có mục nào trong thư mục",
    "Select all" : "Chọn tất cả",
    "Name" : "Tên",
    "Actions" : "Hành động",
    "Deleted" : "Đã xóa",
    "Delete" : "Xóa"
},
"nplurals=1; plural=0;");
