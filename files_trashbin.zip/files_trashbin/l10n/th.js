OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "ไฟล์ที่ถูกลบ",
    "restored" : "การเรียกคืน",
    "Restore" : "คืนค่า",
    "Delete permanently" : "ลบแบบถาวร",
    "This operation is forbidden" : "การดำเนินการนี้ถูกห้าม",
    "This directory is unavailable, please check the logs or contact the administrator" : "ไม่สามารถใช้งานไดเรกทอรีนี้โปรดตรวจสอบบันทึกหรือติดต่อผู้ดูแลระบบ",
    "No deleted files" : "ไม่มีไฟล์ที่ถูกลบ",
    "You will be able to recover deleted files from here" : "คุณจะสามารถกู้คืนไฟล์ที่ถูกได้ลบจากที่นี่",
    "No entries found in this folder" : "ไม่พบรายการในโฟลเดอร์นี้",
    "Select all" : "เลือกทั้งหมด",
    "Name" : "ชื่อ",
    "Actions" : "การกระทำ",
    "Deleted" : "ลบแล้ว",
    "Delete" : "ลบ"
},
"nplurals=1; plural=0;");
