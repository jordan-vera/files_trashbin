OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't restore %s" : "Չկարողացա վերականգնել %s",
    "Deleted files" : "Ջնջված ֆայլեր",
    "Restore" : "Վերականգնել",
    "Delete" : "Ջնջել",
    "Delete permanently" : "Ջնջել ընդմիշտ",
    "Error" : "Սխալ",
    "No deleted files" : "Ջնջված ֆայլեր չկան",
    "Select all" : "Նշել բոլորը",
    "Name" : "Անուն",
    "Deleted" : "Ջնջված"
},
"nplurals=2; plural=(n != 1);");
