OC.L10N.register(
    "files_trashbin",
    {
    "Delete" : "මකා දමන්න",
    "Error" : "දෝෂයක්",
    "Name" : "නම"
},
"nplurals=2; plural=(n != 1);");
