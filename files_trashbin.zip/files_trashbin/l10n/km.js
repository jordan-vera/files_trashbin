OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "មិន​អាច​លុប %s ចោល​ជា​អចិន្ត្រៃយ៍​ទេ",
    "Couldn't restore %s" : "មិន​អាច​ស្ដារ %s ឡើង​វិញ​បាន​ទេ",
    "Deleted files" : "ឯកសារ​ដែល​បាន​លុប",
    "Restore" : "ស្ដារ​មក​វិញ",
    "Delete" : "លុប",
    "Delete permanently" : "លុប​ជា​អចិន្ត្រៃយ៍",
    "Error" : "កំហុស",
    "restored" : "បាន​ស្ដារ​វិញ",
    "Name" : "ឈ្មោះ",
    "Deleted" : "បាន​លុប"
},
"nplurals=1; plural=0;");
