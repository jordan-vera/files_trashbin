OC.L10N.register(
    "files_trashbin",
    {
    "Couldn't delete %s permanently" : "Klarte ikkje sletta %s for godt",
    "Couldn't restore %s" : "Klarte ikkje gjenoppretta %s",
    "Deleted files" : "Sletta filer",
    "Restore" : "Gjenopprett",
    "Delete" : "Slett",
    "Delete permanently" : "Slett for godt",
    "Error" : "Feil",
    "restored" : "gjenoppretta",
    "Name" : "Namn",
    "Deleted" : "Sletta"
},
"nplurals=2; plural=(n != 1);");
