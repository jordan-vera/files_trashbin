OC.L10N.register(
    "files_trashbin",
    {
    "Deleted files" : "Kustutatud failid",
    "restored" : "taastatud",
    "Restore" : "Taasta",
    "Delete permanently" : "Kustuta jäädavalt",
    "This operation is forbidden" : "See toiming on keelatud",
    "This directory is unavailable, please check the logs or contact the administrator" : "See kaust pole saadaval. Palun kontrolli logifaile või võta ühendust administraatoriga",
    "No deleted files" : "Kustutatud faile pole",
    "You will be able to recover deleted files from here" : "Sa saad siit kustutatud faile taastada",
    "No entries found in this folder" : "Selles kaustas ei leitud kirjeid",
    "Select all" : "Vali kõik",
    "Name" : "Nimi",
    "Actions" : "Tegevused",
    "Deleted" : "Kustutatud",
    "Delete" : "Kustuta"
},
"nplurals=2; plural=(n != 1);");
